try:
    from .zepu1chr3 import Binary
except ImportError():
    exit()